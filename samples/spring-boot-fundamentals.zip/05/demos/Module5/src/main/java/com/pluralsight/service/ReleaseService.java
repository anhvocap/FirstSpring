package com.pluralsight.service;

import com.pluralsight.entity.Release;

public interface ReleaseService {
    Iterable<Release> listReleases();
}


