package com.pluralsight.springdataoverview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataOverviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
